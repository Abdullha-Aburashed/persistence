const { processLoanApplication } = require("./business");
const prompt = require("prompt-sync")();

async function main() {
    const name = prompt("Enter customer name: ");
    const requestedAmount = parseFloat(prompt("Enter requested loan amount: "));

    const result = await processLoanApplication(name, requestedAmount);
    console.log(result);
}

main();
