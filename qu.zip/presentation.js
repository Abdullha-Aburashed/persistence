
// no entering transaction, just leaving transactions.

async function exitLot() {
    let id = "CAR003"
    let time = "2025-02-02T09:45:00"
    let cost = await business.leaveParking(id, time)
    console.log(`The cost of the parking was ${cost}`) // cost should be 10 because this is 2 hours
}

exitLot()