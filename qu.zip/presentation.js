const business = require('./business');

/**
 * Testing function to process loan applications.
 * Outputs the status of loan applications before and after processing.
 */
async function processApplications() {
    let status = await business.getApplicationsStatus();
    console.log('Before processing:', status);

    await business.processApplications();

    status = await business.getApplicationsStatus();
    console.log('After processing:', status);
}

processApplications();
