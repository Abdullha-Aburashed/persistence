/**
 * Compute the number of minutes difference between and entryTime and
 * an exit time.  There is absolutely no validation done by this function
 * so you may assume that the exitTime >= entryTime and that the two
 * parameters are valid.
 * 
 * @param {String} entryTime 
 * @param {String} exitTime 
 * @returns The number of minutes between the two times.
 */
function calculateMinutesBetween(entryTime, exitTime) {
    const entryDate = new Date(entryTime);
    const exitDate = new Date(exitTime);
    const diffInMs = exitDate - entryDate;
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60)); // Convert ms to minutes
    return diffInMinutes;
}
