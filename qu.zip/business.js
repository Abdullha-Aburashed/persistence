const { getCustomers, saveApplication } = require("./persistence");

async function processLoanApplication(name, requestedAmount) {
    const customers = await getCustomers();
    const customer = customers.find(c => c.name.toLowerCase() === name.toLowerCase());

    if (!customer) {
        return { application: null, customer: name, status: "Customer not found" };
    }

    const { creditScore, monthlySalary } = customer;

    if (creditScore < 600) {
        return { application: null, customer: name, status: "rejected" };
    }

    const maxLoanAmount = monthlySalary * 5;
    const status = requestedAmount <= maxLoanAmount ? "approved" : "rejected";

    const application = { application: Math.floor(Math.random() * 1000), customer: name, status };
    await saveApplication(application);

    return application;
}

module.exports = { processLoanApplication };
