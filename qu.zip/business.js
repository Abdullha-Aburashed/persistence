const { getCustomers, saveApplication } = require("./persistence");
const fs = require("fs/promises");

/**
 * Process loan application for a specific customer.
 * @param {string} name - Customer's name.
 * @param {number} requestedAmount - Amount requested by the customer.
 * @returns {object} - Application status, customer details, and result of loan application.
 */
async function processLoanApplication(name, requestedAmount) {
    const customers = await getCustomers();
    const customer = customers.find(c => c.name.toLowerCase() === name.toLowerCase());

    if (!customer) {
        return { application: null, customer: name, status: "Customer not found" };
    }

    const { creditScore, salary } = customer;
    const monthlySalary = salary; // Assuming the salary in the customer JSON is the monthly salary

    if (creditScore < 600) {
        return { application: null, customer: name, status: "rejected" };
    }

    const maxLoanAmount = monthlySalary * 5;
    const status = requestedAmount <= maxLoanAmount ? "approved" : "rejected";

    const application = {
        application: Math.floor(Math.random() * 1000), // Random application ID
        customer: name,
        status
    };

    await saveApplication(application);

    return application;
}

/**
 * Process all applications from the `applications.json` and update status.
 */
async function processApplications() {
    const applications = await getApplications();
    const customers = await getCustomers();

    for (const app of applications) {
        const customer = customers.find(c => c.id === app.customerId);
        if (customer) {
            const { requestedAmount } = app;
            const result = await processLoanApplication(customer.name, requestedAmount);
            app.status = result.status;
            await saveApplication(app);
        }
    }
}

/**
 * Get the current status of all applications.
 * @returns {Array} - Array of application status objects.
 */
async function getApplicationsStatus() {
    const applications = await getApplications();
    return applications.map(app => ({
        application: app.id,
        customer: app.customerId, // You can modify this to get the customer name if you need
        status: app.status
    }));
}

/**
 * Get all loan applications from storage.
 * @returns {Array} - Array of application objects.
 */
async function getApplications() {
    const data = await fs.readFile('applications.json', 'utf-8');
    return JSON.parse(data);
}

module.exports = { processLoanApplication, processApplications, getApplicationsStatus };
