import requests

API_BASE = "http://api.alquran.cloud/v1"

def q1():
    """Fetch the Quran surahs using the 'en.asad' edition and count Meccan & Medinan surahs."""
    # Fetch the Quran surahs using the "en.asad" edition
    response = requests.get(f"{API_BASE}/quran/en.asad")
    if response.status_code != 200:
        print("Error fetching data for Q1")
        return
    
    quran_data = response.json()['data']
    
    meccan_count = 0
    medinan_count = 0

    # Count surahs by revelation type
    for surah in quran_data['surahs']:
        if surah['revelationType'] == "Meccan":
            meccan_count += 1
        elif surah['revelationType'] == "Medinan":
            medinan_count += 1

    # Save results to Q1.txt
    with open("Q1.txt", "w") as file:
        file.write(f"Meccan surahs: {meccan_count}\n")
        file.write(f"Medinan surahs: {medinan_count}\n")

def q2():
    """Fetch Quran chapters and find those spread across multiple Hizb quarters."""
    response = requests.get(f"{API_BASE}/quran/en.asad")
    if response.status_code != 200:
        print("Error fetching data for Q2")
        return

    quran_data = response.json()['data']
    
    distributed_surahs = []

    for surah in quran_data['surahs']:
        quarters = set(ayah['hizbQuarter'] for ayah in surah['ayahs'])
        if len(quarters) > 1:
            distributed_surahs.append(f"{surah['englishName']} ({surah['englishNameTranslation']}) - Quarters {sorted(quarters)}")

    with open("Q2.txt", "w") as file:
        file.write("Surahs distributed across multiple quarters:\n")
        file.write("\n".join(distributed_surahs))

if __name__ == "__main__":
    q1()
    q2()
