// persistence layer
const fs = require("fs/promises");

const dataFile = "customer.json"; // Customer data storage
const applicationsFile = "applications.json"; // Loan application data storage

/**
 * Get all customers from the database.
 * @returns {Array} - Array of customer objects.
 */
async function getCustomers() {
    const data = await fs.readFile(dataFile, "utf-8");
    return JSON.parse(data);
}

/**
 * Save a loan application to the database.
 * @param {object} application - Application details to be saved.
 */
async function saveApplication(application) {
    let applications = [];
    try {
        const existingData = await fs.readFile(applicationsFile, "utf-8");
        applications = JSON.parse(existingData);
    } catch {
        // If file doesn't exist, start fresh
    }
    applications.push(application);
    await fs.writeFile(applicationsFile, JSON.stringify(applications, null, 2));
}

module.exports = { getCustomers, saveApplication };
