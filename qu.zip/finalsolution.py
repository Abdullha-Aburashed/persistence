import requests

API_BASE = "http://api.alquran.cloud/v1"

def q1():
    # Fetch the Quran surahs using the "en.asad" edition
    response = requests.get(f"{API_BASE}/quran/en.asad")
    if response.status_code != 200:
        print("Error fetching data for Q1")
        return
    
    quran_data = response.json()['data']
    
    meccan_count = 0
    medinan_count = 0

    # Count surahs by revelation type
    for surah in quran_data['surahs']:
        if surah['revelationType'] == "Meccan":
            meccan_count += 1
        elif surah['revelationType'] == "Medinan":
            medinan_count += 1

    # Save results to Q1.txt
    with open("Q1.txt", "w") as file:
        file.write(f"Meccan surahs: {meccan_count}\n")
        file.write(f"Medinan surahs: {medinan_count}\n")

def q2():
    # Fetch the Quran data using "en.asad"
    response = requests.get(f"{API_BASE}/quran/en.asad")
    if response.status_code != 200:
        print("Error fetching data for Q2")
        return

    quran_data = response.json()['data']
    
    total_ayahs = 0
    surah_ayahs = []

    # Count ayahs per surah
    for surah in quran_data['surahs']:
        ayah_count = len(surah['ayahs'])
        total_ayahs += ayah_count
        surah_ayahs.append(f"Surah {surah['number']}: {ayah_count} ayahs")

    # Save results to Q2.txt
    with open("Q2.txt", "w") as file:
        file.write(f"Total ayahs in the Quran: {total_ayahs}\n\n")
        file.write("Ayah count per surah:\n")
        file.write("\n".join(surah_ayahs))

if __name__ == "__main__":
    q1()
    q2()
