import requests

def q1():
    # Fetch the list of surahs
    response = requests.get('http://api.alquran.cloud/v1/surah')
    surahs = response.json()['data']

    # Count surahs by revelation type
    meccan_count = sum(1 for surah in surahs if surah['revelationType'] == 'Meccan')
    medinan_count = sum(1 for surah in surahs if surah['revelationType'] == 'Medinan')

    # Write the counts to Q1.txt
    with open('Q1.txt', 'w') as file:
        file.write(f"Meccan surahs: {meccan_count}\n")
        file.write(f"Medinan surahs: {medinan_count}\n")

def q2():
    # Fetch the complete Quran in the specified edition
    response = requests.get('http://api.alquran.cloud/v1/quran/en.asad')
    quran = response.json()['data']

    # Initialize counters
    total_ayahs = 0
    surah_ayahs = []

    # Count ayahs in each surah
    for surah in quran['surahs']:
        ayah_count = len(surah['ayahs'])
        total_ayahs += ayah_count
        surah_ayahs.append(f"Surah {surah['number']}: {ayah_count} ayahs")

    # Write the counts to Q2.txt
    with open('Q2.txt', 'w') as file:
        file.write(f"Total ayahs in the Quran: {total_ayahs}\n\n")
        file.write("Ayah count per surah:\n")
        file.write("\n".join(surah_ayahs))

if __name__ == '__main__':
    q1()
    q2()
