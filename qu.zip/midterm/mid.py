import requests

url = "https://wizard-world-api.herokuapp.com"

   
def q1():
    response = requests.get(f"{url}/elixirs")
    x = response.json()
    diff_group = {}
    for i in x:
        diff = i.get('difficulty' , 'Unknown')
        if diff not in diff_group:
            diff_group[diff] = []
        diff_group[diff].append(i['name'])
    with open('q1.txt', 'w') as f:
        for diff, names in sorted(diff_group.items()):
            f.write("Difficulty " + diff + ":\n")
            for name in sorted(names):
                f.write("-: " + name + "\n")
            f.write("\n")
        
def q2():
    response = requests.get(f"{url}/spells")
    x = response.json()
    Light_group = {}
    for i in x:
        light = i.get('light')
        if light:
            if light not in Light_group:
                Light_group[light] = []
            Light_group[light].append(i['name'])
    with open('q2.txt', 'w') as f:
        for light, names in sorted(Light_group.items()):
            f.write("Light " + light + ":\n")
            for name in sorted(names):
                f.write("-: " + name + "\n")
            f.write("\n")
             
def q3():
    response = requests.get(f"{url}/elixirs")
    x = response.json() 
    color_group = {}
    for i in x:
        ch = i.get('characteristics')
        color = None
        if ch and 'colores' in ch.lower() :
            color = ch.split('colred')[0].strip()
        color_hint = color or 'no coloer'
        if color_hint not in color_group:
            color_group[color_hint] = []
        color_group[color_hint].append(i['name'])
    with open('q3.txt', 'w') as f:
        for color, names in sorted(color_group.items()):
            f.write("Characteristics " + color + ":\n")
            for name in sorted(names):
                f.write("-: " + name + "\n")
            f.write("\n")   
        
        
q1()
q2()
q3()
