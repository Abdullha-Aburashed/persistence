// persistence layer
const fs = require("fs/promises");

const dataFile = "customers.json"; // Customer data storage

async function getCustomers() {
    const data = await fs.readFile(dataFile, "utf-8");
    return JSON.parse(data);
}

async function saveApplication(application) {
    let applications = [];
    try {
        const existingData = await fs.readFile("applications.json", "utf-8");
        applications = JSON.parse(existingData);
    } catch {
        // If file doesn't exist, start fresh
    }
    applications.push(application);
    await fs.writeFile("applications.json", JSON.stringify(applications, null, 2));
}

module.exports = { getCustomers, saveApplication };
