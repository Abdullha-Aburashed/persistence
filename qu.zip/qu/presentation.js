const business = require('./business')

/**
 * Really a testing function but you should be able to see the original file with no
 * loans processed then after processing the applications the output should change to 
 * approved or not approved depending on the customer.
 */
async function processApplications() {
    let status = await business.getStatus()
    console.log(status)
    await business.processApplications()
    status = await business.getStatus()
    console.log(status)
}


processApplications()


