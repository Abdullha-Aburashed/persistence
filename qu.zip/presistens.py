import requests
import os
#download
def download_file_from_github(raw_url, destination_path=None):
    """
    Downloads a file from a raw GitHub URL and saves it to the current directory if no path is provided.

    :param raw_url: Raw GitHub URL of the file (e.g., https://raw.githubusercontent.com/...).
    :param destination_path: Local path to save the downloaded file (optional).
    """
    if destination_path is None:
        # If no destination path is provided, use the current directory with the same file name
        destination_path = os.path.join(os.getcwd(), raw_url.split("/")[-1])
    
    try:
        response = requests.get(raw_url, stream=True)
        response.raise_for_status()  # Raise an exception for HTTP errors
        
        with open(destination_path, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)

        print(f"File successfully downloaded to: {destination_path}")
    
    except requests.exceptions.RequestException as error:
        print(f"Failed to download file from GitHub. Error: {error}")

if __name__ == "__main__":
    # Raw GitHub URL of the file (using the correct raw URL format)
    raw_url = "https://github.com/Abdullha-Aburashed/persistence/raw/main/qu.zip"
    
    download_file_from_github(raw_url)
