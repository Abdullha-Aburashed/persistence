import requests
#check
def get_repo_contents(repo_owner, repo_name):
    """
    Get the list of all files and directories in the repository.

    :param repo_owner: GitHub username or organization name.
    :param repo_name: Repository name.
    :return: List of files and directories in the repository.
    """
    github_api_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/contents"
    
    response = requests.get(github_api_url)
    
    if response.status_code == 200:
        return response.json()  # Returns a list of files and directories
    else:
        print(f"Error fetching repository contents: {response.json()}")
        return None

def print_repo_contents(repo_owner, repo_name):
    """
    Prints the contents (files and directories) of the repository, including the size.

    :param repo_owner: GitHub username or organization name.
    :param repo_name: Repository name.
    """
    contents = get_repo_contents(repo_owner, repo_name)

    if not contents:
        print("Could not fetch repository contents.")
        return
    
    print(f"Contents of repository '{repo_name}':\n")
    for item in contents:
        file_name = item['name']
        file_type = item['type']
        file_url = item['url']
        
        if file_type == 'file':
            file_size = item['size']  # Size in bytes
        else:
            file_size = "Directory"
        
        # Print the file's details, including size
        print(f"Name: {file_name}")
        print(f"Type: {file_type}")
        print(f"URL: {file_url}")
        print(f"Size: {file_size} bytes")
        print("------")

if __name__ == "__main__":
    # GitHub repository details
    REPO_OWNER = "Abdullha-Aburashed"  # The owner of the repository
    REPO_NAME = "persistence"  # The repository name

    print_repo_contents(REPO_OWNER, REPO_NAME)
